import TPPL
def ReadPoly(f):
	p=TPPL.Poly()
	n=int(f.readline())
	p.Init(n)
	p.hole=int(f.readline())>0
	for i in range(n):
		line=f.readline()
		vals=line.split()
		p.points.append(TPPL.Point(int(vals[0]),int(vals[1])))
	if((p.GetOrientation()==1) == p.hole):
		p.Invert()
	return p

def ReadPolyList(filename):
	f=open(filename,"r")
	l=[]
	for i in range(0,int(f.readline())):
		l.append(ReadPoly(f))
	return l

l=ReadPolyList("test2.txt")
#TPPL.Parition(max_length,min_detail)
pa=TPPL.Partition(25000,10000)
TPPL.Draw(l,'./test_original.svg')
TPPL.Draw(pa.RemoveHoles(l),'./test_hole.svg')
TPPL.Draw(pa.Triangulate_EC_list(l),'./test_triangle.svg')
TPPL.Draw(pa.ConvexPartition_HM_list(l),'./test_partition.svg')
